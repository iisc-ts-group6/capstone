<?php
error_reporting(0);
session_start();
ob_start();

define('SERVER', 'localhost');
define('USER', 'root');
define('PASSWORD', '');
define('DB', 'online_exam_system');

$conn = mysqli_connect(SERVER, USER, PASSWORD, DB);// CONNECT DATABASE

if($conn->connect_error){
    die('Connect Error: ' . $mysqli->connect_error);
}
/*  echo "Connected successfully";
exit;  */
?>
