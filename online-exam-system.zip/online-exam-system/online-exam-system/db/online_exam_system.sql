-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2024 at 03:43 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_exam_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `assessment`
--

CREATE TABLE `assessment` (
  `id` int(11) NOT NULL,
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assessment`
--

INSERT INTO `assessment` (`id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'assessment-1', 1, '2024-06-29 17:35:13', '2024-06-29 17:35:13'),
(2, 'assessment-2', 1, '2024-06-29 17:35:58', '2024-06-29 17:35:58'),
(3, 'assessment-3', 1, '2024-06-29 17:40:24', '2024-06-29 17:40:24'),
(4, 'assessment-4', 1, '2024-07-02 12:12:49', '2024-07-02 16:57:52');

-- --------------------------------------------------------

--
-- Table structure for table `attempt_exam`
--

CREATE TABLE `attempt_exam` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `assessment_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `question` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `answer` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attempt_exam`
--

INSERT INTO `attempt_exam` (`id`, `user_id`, `assessment_id`, `question_id`, `question`, `answer`, `created_at`) VALUES
(1, 2, 2, 2, 'What is needed for photosynthesis?', 'dfsdfsf', '2024-07-02 16:00:04'),
(2, 2, 2, 3, 'Mention the role of the radula in Molluscs.', 'sdfsf', '2024-07-02 16:00:04'),
(3, 2, 2, 4, 'What is the importance of pneumatic bones and air sacs in Aves?', 'sfsfs', '2024-07-02 16:00:04'),
(4, 2, 2, 5, 'What do you mean by tonoplast?', 'sdfsfsf', '2024-07-02 16:00:04'),
(5, 2, 2, 6, 'Name the plant on which Mendel performed his experiments.', 'sfdsfs', '2024-07-02 16:00:04'),
(6, 2, 2, 7, 'What is heredity?', 'sfsfsf', '2024-07-02 16:00:04'),
(7, 2, 2, 8, 'What is a retrovirus?', 'sdfsfs', '2024-07-02 16:00:04'),
(8, 2, 2, 9, 'What are the components of the chromosome?', 'gdgdg', '2024-07-02 16:00:04'),
(9, 2, 2, 10, 'Define homologous organs.', 'dfgdg', '2024-07-02 16:00:05'),
(10, 2, 2, 11, 'How does the creation of variations in a species promote survival?', 'dfgdgd', '2024-07-02 16:00:05'),
(11, 5, 2, 2, 'What is needed for photosynthesis?', 'dfdss sfds sdfsd sdf sf sfsd sdfsdf sd sfds fsd sfdsfsf', '2024-07-02 17:11:06'),
(12, 5, 2, 3, 'Mention the role of the radula in Molluscs.', 'sd fs sfs d fdsfs sdsdfs fdsf gdgsd sd sd', '2024-07-02 17:11:06'),
(13, 5, 2, 4, 'What is the importance of pneumatic bones and air sacs in Aves?', 's fdds sds d', '2024-07-02 17:11:06'),
(14, 5, 2, 5, 'What do you mean by tonoplast?', 's fds fsfd s fds ', '2024-07-02 17:11:06'),
(15, 5, 2, 6, 'Name the plant on which Mendel performed his experiments.', 's dfs s sf sf sfd', '2024-07-02 17:11:06'),
(16, 5, 2, 7, 'What is heredity?', 's fsdf sfs', '2024-07-02 17:11:06'),
(17, 5, 2, 8, 'What is a retrovirus?', 'sfd sfsdf sdf s', '2024-07-02 17:11:06'),
(18, 5, 2, 9, 'What are the components of the chromosome?', 'sdf sdf s fs ', '2024-07-02 17:11:06'),
(19, 5, 2, 10, 'Define homologous organs.', 'sf sdf sfsf sfssf', '2024-07-02 17:11:07'),
(20, 5, 2, 11, 'How does the creation of variations in a species promote survival?', 'sf sf sfsfd', '2024-07-02 17:11:07');

-- --------------------------------------------------------

--
-- Table structure for table `question_answer`
--

CREATE TABLE `question_answer` (
  `id` int(11) NOT NULL,
  `assessment_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `question_text` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `reference_answer` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `student_answer` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `model_evaluation_result` varchar(250) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `question_answer`
--

INSERT INTO `question_answer` (`id`, `assessment_id`, `question_id`, `question_text`, `reference_answer`, `student_answer`, `model_evaluation_result`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'What is needed for photosynthesis?', 'Carbondioxide and Sunlight', '', '', 1, '2024-06-29 15:57:04', '2024-06-29 16:44:15'),
(2, 2, 1, 'What is needed for photosynthesis?', 'Carbondioxide and Sunlight', '', '', 1, '2024-06-29 16:00:09', '2024-06-29 16:29:10'),
(3, 2, 2, 'Mention the role of the radula in Molluscs.', 'The radula helps in scraping and scratching the food and creates depressions in the rocks', '', '', 1, '2024-06-29 16:00:09', '2024-06-29 16:29:10'),
(4, 2, 3, 'What is the importance of pneumatic bones and air sacs in Aves?', 'Pneumatic bones, the hollow bones and air sacs in birds helps them in flying.', '', '', 1, '2024-06-29 16:00:10', '2024-06-29 16:29:10'),
(5, 2, 4, 'What do you mean by tonoplast?', 'Membrane boundary of the vacuole present in plant cells', '', '', 1, '2024-06-29 16:00:10', '2024-06-29 16:29:10'),
(6, 2, 5, 'Name the plant on which Mendel performed his experiments.', 'Mendel performed his experiments on the plant, Pisum sativum ? the garden pea plant.', '', '', 1, '2024-06-29 16:00:10', '2024-06-29 16:29:10'),
(7, 2, 6, 'What is heredity?', 'The continuity of features from one generation to another is known as heredity. It is also defined as the transmission of traits from parents to the offsprings.', '', '', 1, '2024-06-29 16:00:10', '2024-06-29 16:29:10'),
(8, 2, 7, 'What is a retrovirus?', 'A retrovirus is a virus that has RNA as its genetic material instead of DNA. HIV virus is a retrovirus.', '', '', 1, '2024-06-29 16:00:10', '2024-06-29 16:29:10'),
(9, 2, 8, 'What are the components of the chromosome?', 'A chromosome consists of two Chromatids joined together at the centromere. The chromaid consists of the DNA material wound over small protein molecules called histones.', '', '', 1, '2024-06-29 16:00:10', '2024-06-29 16:29:10'),
(10, 2, 9, 'Define homologous organs.', 'Homologous organs are those organs, which have similar origin and basic plan of development, but may or may not differ in their functions. ', '', '', 1, '2024-06-29 16:00:10', '2024-06-29 16:29:10'),
(11, 2, 10, 'How does the creation of variations in a species promote survival?', 'Variations increases the adaptability of an organism to its changing environmental conditions.', '', '', 1, '2024-06-29 16:00:10', '2024-06-29 16:29:10'),
(12, 4, 1, 'What is needed for photosynthesis?', 'Carbondioxide and Sunlight', '', '', 1, '2024-06-29 17:22:49', '2024-06-29 17:22:49'),
(13, 1, 1, 'What is needed for photosynthesis?', 'Carbondioxide and Sunlight', '', '', 1, '2024-06-29 17:36:11', '2024-06-29 17:36:11'),
(14, 3, 1, 'What is needed for photosynthesis?', 'Carbondioxide and Sunlight', '', '', 1, '2024-06-29 17:40:37', '2024-06-29 17:40:37'),
(15, 4, 1, 'What is needed for photosynthesis?', 'Carbondioxide and Sunlight', '', '', 1, '2024-07-02 17:14:18', '2024-07-02 17:14:18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `last_name` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `mobile_no` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(250) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `last_login` datetime NOT NULL,
  `user_type` int(11) NOT NULL COMMENT '1 for admin,2 for user',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `mobile_no`, `password`, `status`, `last_login`, `user_type`, `created_at`, `updated_at`) VALUES
(1, 'Teacher', 'user', 'teacher@mailinator.com', '', '25d55ad283aa400af464c76d713c07ad', 1, '2024-06-28 14:59:09', 1, '2024-06-28 18:29:42', '2024-07-02 17:12:29'),
(2, 'test', 'test', 'test@mailinator.com', '', '25d55ad283aa400af464c76d713c07ad', 1, '0000-00-00 00:00:00', 2, '2024-07-01 17:51:19', '2024-07-01 17:51:19'),
(3, 'test', 'user1', 'testuser1@mailinator.com', '', '25d55ad283aa400af464c76d713c07ad', 1, '0000-00-00 00:00:00', 2, '2024-07-01 18:27:14', '2024-07-01 18:27:14'),
(4, 'gdg', 'dfg', 's', '', 'e10adc3949ba59abbe56e057f20f883e', 1, '0000-00-00 00:00:00', 2, '2024-07-01 23:11:46', '2024-07-01 23:11:46'),
(5, 'test', 'user', 'test1@mailinator.com', '', '25d55ad283aa400af464c76d713c07ad', 1, '0000-00-00 00:00:00', 2, '2024-07-02 16:54:36', '2024-07-02 17:09:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assessment`
--
ALTER TABLE `assessment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attempt_exam`
--
ALTER TABLE `attempt_exam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question_answer`
--
ALTER TABLE `question_answer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assessment`
--
ALTER TABLE `assessment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `attempt_exam`
--
ALTER TABLE `attempt_exam`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `question_answer`
--
ALTER TABLE `question_answer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
