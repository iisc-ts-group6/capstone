

<?php
include("include/config.php");
if(isset($_SESSION['auth'])){
    header('Location:dashboard.php');
    exit;
    }
if($_POST){
   
    $email = (isset($_POST['email'])) ? $_POST['email'] : '';
    $password = (isset($_POST['password'])) ? $_POST['password'] : '';
	
    if($email != '' && $password != '')
    {
        $query = "SELECT  * FROM users WHERE email = '".$email."' AND password = '".md5($password)."' AND status=1 AND user_type='2'";
        $result = mysqli_query($conn,$query);
        if($result){
            if(mysqli_num_rows($result) > 0){
                $row = mysqli_fetch_assoc($result);
				$_SESSION['user'] = $row ;
				$_SESSION['msg']['success'] = "<b>Welcome!</b> Login successfully.";
				echo'<script>window.location="dashboard.php";</script>';
            }else{
                $_SESSION['msg']['fail'] = "Invalid username or password";
            }
        }else{
            $_SESSION['msg']['fail'] = "Somthing want wrong!";
        }
    }else{
        $_SESSION['msg']['fail'] = "All fields are required!";
    }

  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Biology Assessment Portal</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="js/jquery.min.js"></script>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<script src="js/bootstrap.bundle.min.js"></script>
	<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	<link rel="stylesheet" href="parsley/css/parsley.css">
	


	<link href="" rel="stylesheet">
	<style>
		#infoMessage p {
			color: red;
		}
		.loginright{
			Background-color:rgba(222,222,222,0.3);
			border-radius:20px;
			box-shadow:0 0 5px 3px rgba(222,222,222,0.5);
			backdrop-filter: blur(10px);
			padding:30px 60px;
		}
		.login-bg{
			width:100%;
			height:100vh;
			background-image:url('img/background.jpg');
			background-size:135%;
			background-position:left;
			background-color:rgba(0,0,0,0.7);
			background-blend-mode:darken;
			overflow:auto;
			justify-content:center;
			align-items:center;
			display:flex;

		}
		.logologin img{
			width:100px;
			margin:10px auto;
		}
		.forgetline{
			margin:-20px auto;
		}
		.logologin{
			position:fixed;
			top:20px;
			left:20px;
		}
		.contin{
			color:white;
			border-color:white!important;
			transition:0.5s;
		}
		.contin:hover{
			background-color:black;
			color:white;
			border-color:black!important;
		}
	</style>
</head>

<body>

	<section class="login-bg">
		<div class="container-fluid addevent">
			<div class="row justify-content-center">
					<div class="col-4 loginright">
					
				<h5 class="text-center text-white fs-3">Welcome Back</h5>
				<p class="text-center text-white mb-5">Please enter your Email and Password</p>

                
				<form action="login.php" class="myForm" method="post" accept-charset="utf-8">
				<?php include('include/flash.php'); ?>
				<div class="mb-3">
					<label for="email" class="form-label text-white">Email</label>
					<!-- <input type="email" class="form-control rounded-pill" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your Email Address"> -->
					<input type="text" name="email" class="form-control rounded-2" id="name" placeholder="Enter your Email Address" data-parsley-required-message="Email is required" autocomplete="off" data-parsley-trigger="change" required="" value="" style="padding: 7px;">

				</div>
				<div class="mb-3">
					<label for="exampleInputPassword1" class="form-label text-white">Password</label>
					<input type="password" title="Password" id="pass" placeholder="Enter your Password......" class="form-control rounded-2 required-entry validate-password" name="password" data-parsley-required-message="Password is required" autocomplete="off" data-parsley-trigger="change" required="" style="padding: 7px;">

				</div>
				
				<button type="submit" class="btn btn-primary rounded-3 w-100" id="send2" style=" background-color: #27AE60;border: 1px solid #27AE60;">Login...... <svg xmlns="http://www.w3.org/2000/svg" width="51" height="26" viewBox="0 0 51 26" fill="none">
						<path d="M50.7305 13.3472C50.7305 12.8599 50.5472 12.3767 50.1765 12.006L39.4643 1.30187C39.2685 1.09947 39.0158 0.961584 38.7396 0.906326C38.5411 0.872452 38.3375 0.882036 38.1431 0.934797C37.9487 0.98756 37.7681 1.08227 37.6139 1.21188C37.4597 1.3415 37.3356 1.50329 37.2502 1.68573C37.1649 1.86816 37.1202 2.06694 37.1195 2.26837V9.22348L18.7854 9.22348C18.0149 9.22348 17.3944 9.8445 17.3944 10.615V16.1623C17.3944 16.5313 17.5409 16.8852 17.8018 17.1461C18.0627 17.407 18.4165 17.5533 18.7854 17.5533L37.1195 17.5533V24.5466C37.1195 25.7336 38.6188 26.333 39.456 25.4917L50.1765 14.6966C50.353 14.5191 50.4928 14.3084 50.5879 14.0768C50.6829 13.8452 50.7314 13.5975 50.7305 13.3472ZM13.2253 10.2647C13.2253 9.68579 12.7588 9.22348 12.184 9.22348H10.1016C9.82541 9.22348 9.56057 9.33326 9.3653 9.52853C9.17003 9.72379 9.06033 9.98856 9.06033 10.2647V16.5121C9.06033 16.7883 9.17003 17.0535 9.3653 17.2488C9.56057 17.4441 9.82541 17.5533 10.1016 17.5533H12.184C12.4602 17.5533 12.725 17.4441 12.9203 17.2488C13.1156 17.0535 13.2253 16.7883 13.2253 16.5121V10.2647ZM4.8954 10.2647C4.8954 9.68579 4.42892 9.22348 3.85416 9.22348H1.7717C1.49555 9.22348 1.23071 9.33326 1.03544 9.52853C0.840168 9.72379 0.730469 9.98856 0.730469 10.2647V16.5121C0.730469 16.7883 0.840168 17.0535 1.03544 17.2488C1.23071 17.4441 1.49555 17.5533 1.7717 17.5533H3.85416C4.13032 17.5533 4.39516 17.4441 4.59043 17.2488C4.7857 17.0535 4.8954 16.7883 4.8954 16.5121V10.2647Z" fill="white" />
					</svg></button>
				</form>
				<!-- <a href="https://localyft.store/Localyft_marketplace_1/Auth/forgot_password">
					<p class="forgetpassword border-bottom p-0 my-2 text-white text-end fw-normal pb-4">Forget password?</p>
				</a> -->
				
				<div class="forgetline"></div>
				<br>
				<br>
				
				<div class="d-flex justify-content-between align-items-center">
				<p class="donthave text-white fw-normal mt-3">Don't have an account yet? </p>
				<a href="register.php" class="ms-3 text-white text-decoration-underline">Create Account</a>
				</div>
				</form>
					</div>
				</div>
	
		</div>
	</section>
</body>
<script src="js/toast.js"></script>
<link rel="stylesheet" href="parsley/js/parsley.js">
<script src="parsley/validate.js"></script>
</html>




<!-- old pattern form   -->
