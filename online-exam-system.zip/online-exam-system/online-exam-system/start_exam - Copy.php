<?php

include('include/config.php');
if(!isset($_SESSION['user']) && empty($_SESSION['user'])){
header('Location:login.php');
exit;
}

if (isset($_REQUEST['id']) && $_REQUEST['id'] != '') {
    $query = "SELECT * FROM question_answer WHERE status = 1 AND assessment_id='".$_REQUEST['id'] ."'";
    $res = mysqli_query($conn, $query);
}

if (isset($_POST['submit'])) {
    $question_id = (isset($_POST['question_id'])) ? $_POST['question_id'] : '';
    $question = (isset($_POST['question'])) ? $_POST['question'] : '';
    $answer = (isset($_POST['answer'])) ? $_POST['answer'] : '';
    foreach (array_filter($question_id)as $key => $value) {
        $valueData[$key]['question_id'] = $value;
    }
    foreach (array_filter($question)as $key => $value) {
        $valueData[$key]['question'] = $value;
    }
    foreach (array_filter($answer)as $key => $value) {
        $valueData[$key]['answer'] = $value;
    }
    foreach ($valueData as $key => $value) {
        $user_id = $_SESSION;
        $assessment_id = $_POST['assessment_id'];
        $question_ids = $value['question_id'];
        $questions = $value['question'];
        $answers = $value['answer'];
        $sql = "INSERT into  attempt_exam (user_id,question_id,question,answer,assessment_id) 
        values ('".$user_id."','".$question_ids."','".$questions."','".$answers."','".$assessment_id."')";
        $addrun = mysqli_query($conn, $sql);
    }
    
    if ($addrun) {
        $_SESSION['msg']['success'] = 'Your assessment submitted Successfully.';
        header('location:dashboard.php');exit;
    } else {
        $_SESSION['msg']['fail'] = 'Assessment Submit Fail';
        header('location:dashboard.php');exit;
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Start Exam</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <style></style>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
       <?php include('include/header.php'); ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                   
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">


                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Test User</span>
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="logout.php">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Start Your Exam Now !</h1>
                        <form method="post" action="start_exam.php" class="myForm">
                            <input type="hidden" name="assessment_id" value="<?php echo $_REQUEST['id']; ?>">
                            <div class="row  mb-4">
                                <div class="col-md-2">
                                </div>
                                    <div class="col-md-8 bg-white">
                                    <?php 
                                    if($res){
                                        $count = 0;
                                        while($data = mysqli_fetch_assoc($res)){
                                            $count++;
                                    ?>  
                                    
                                        <div class="mb-4 mt-4">
                                            <label for="email" class="form-label"><h5><?php echo $count; ?>. <?php echo $data['question_text']?></h5></label>
                                            <input type="hidden" id="question_id" name="question_id[]" value="<?php echo $data['id']?>">
                                            <input type="hidden" id="question" name="question[]" value="<?php echo $data['question_text']?>">
                                            <textarea placeholder="Enter Your Answer" name="answer[]" class="form-control" maxlength="200"></textarea>
                                        </div>
                                    <?php } } ?>
                                        <div class="mb-4">
                                            <button type="submit" name="submit" class="btn btn-primary">Next</button>
                                            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    
                                </div>
                                <div class="col-md-2">
                                </div>
                            </div>
                            
                        </form>
                        
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; <?php echo date('Y');_?></span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>
    <script type="text/javascript">
$(function () {
  var $sections = $('.form-section');

  function navigateTo(index) {
    // Mark the current section with the class 'current'
    $sections
      .removeClass('current')
      .eq(index)
        .addClass('current');
    // Show only the navigation buttons that make sense for the current section:
    $('.form-navigation .previous').toggle(index > 0);
    var atTheEnd = index >= $sections.length - 1;
    $('.form-navigation .next').toggle(!atTheEnd);
    $('.form-navigation [type=submit]').toggle(atTheEnd);
  }

  function curIndex() {
    // Return the current index by looking at which section has the class 'current'
    return $sections.index($sections.filter('.current'));
  }

  // Previous button is easy, just go back
  $('.form-navigation .previous').click(function() {
    navigateTo(curIndex() - 1);
  });

  // Next button goes forward iff current block validates
  $('.form-navigation .next').click(function() {
    $('.demo-form').parsley().whenValidate({
      group: 'block-' + curIndex()
    }).done(function() {
      navigateTo(curIndex() + 1);
    });
  });

  // Prepare sections by setting the `data-parsley-group` attribute to 'block-0', 'block-1', etc.
  $sections.each(function(index, section) {
    $(section).find(':input').attr('data-parsley-group', 'block-' + index);
  });
  navigateTo(0); // Start at the beginning
});
</script>
</body>

</html>