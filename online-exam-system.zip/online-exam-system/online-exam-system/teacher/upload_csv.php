<?php

include('include/config.php');
if(!isset($_SESSION['auth']) && empty($_SESSION['auth'])){
header('Location:login.php');
exit;
}
if(isset($_POST["submit"])){
    
    $assessment_id = (isset($_POST['assessment_id'])) ? $_POST['assessment_id'] : '';
   $status = '1';
    $filename=$_FILES["file"]["tmp_name"];  
     if($_FILES["file"]["size"] > 0)
     {
        $file = fopen($filename, "r");
          while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
           {
            
            if($getData[1] != 'Question_Text'){
                $sql = "INSERT into question_answer (assessment_id,question_id,question_text,reference_answer,student_answer,model_evaluation_result,status) 
                   values ('".$assessment_id."','".$getData[0]."','".$getData[1]."','".$getData[2]."','".$getData[3]."','".$getData[4]."','".$status."')";
                   $addrun = mysqli_query($conn, $sql);
                   
                   if ($addrun) {
                    $_SESSION['msg']['success'] = 'Data Upload  Successfully.';
                    header('location:question.php');exit;
                } else {
                    $_SESSION['msg']['fail'] = 'Data upload Fail';
                    header('location:add_assestment.php');exit;
                }
            }
             
                   /*  echo "<pre>";
                   print_r($sql);
                   exit;  */
                     
           }
      
           fclose($file);  
     }
}
$query = "SELECT * FROM assessment WHERE status = 1";
        $res = mysqli_query($conn, $query);
        if($res && mysqli_num_rows($res) > 0){
            while ($row = mysqli_fetch_assoc($res)) {
                $data[] = $row;
            }
        }
       
$allAssestment = $data;

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="parsley/css/parsley.css">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php  include('include/header.php'); ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                   
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">


                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Admin</span>
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="logout.php">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Assestment</h1>
                    <div>
                    <?php
                    if (isset($_REQUEST['id']) && $_REQUEST['id'] != '') {
                      $id = $_REQUEST['id'];
                      $assestmentqry = "select * from assessment where id = '" . $id . "'";
                      $assestmentrun = mysqli_query($conn, $assestmentqry);
                      $assestmentrecord = mysqli_fetch_assoc($assestmentrun);
                    }
                    ?>     
                        <form method="post" action="upload_csv.php" class="myForm" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?php if (isset($_REQUEST['id'])) {echo $assestmentrecord['id'];}?>">
                            <div class="row  mb-4">
                                <div class="col-md-4">
                                </div>
                                <div class="col-md-4 bg-white">
                                    <div class="mb-4 mt-4">
                                        <label for="exampleInputName1">Assestment<span class="text-danger">*</span></label>
                                        <select class="form-control" id="assessment_id" style="width:100%" name="assessment_id" required="" data-parsley-errors-container="#error-bank">
                                            <option value="">Select Assestment</option>
                                            <?php if(isset($allAssestment) && !empty($allAssestment)){ ?>
                                                <?php foreach ($allAssestment as $key => $value) { ?>
                                                <option value="<?php echo $value['id']; ?>"> <?php echo $value['name'] ?> </option>
                                                <?php } ?>
                                            <?php } ?>
                                        </select>
                                        <span id="error-bank"></span>
                                    </div>
                                    <div class="mb-4 mt-3">
                                        <label for="email" class="form-label">Upload File<span class="text-danger">*</span></label><a style="float:right" href="csv-demo/question_format.csv" target="_blank">Download Format</a>
                                        <input type="file" class="form-control" id="file" data-parsley-required-message="File is required" autocomplete="off" data-parsley-trigger="change" name="file" required value="">
                                    </div>
                                    <div class="mb-4">
                                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                </div>
                            </div>
                            
                        </form>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

  

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>
    <script src="parsley/js/parsley.js"></script>
    <script src="parsley/validate.js"></script>

</body>

</html>